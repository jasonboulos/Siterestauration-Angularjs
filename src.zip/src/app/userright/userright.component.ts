import { Component } from '@angular/core';

@Component({
  selector: 'app-userright',
  templateUrl: './userright.component.html',
  styleUrls: ['./userright.component.css']
})
export class UserrightComponent {

}
